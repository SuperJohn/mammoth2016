# coding:utf-8
from django.conf.urls import patterns, include, url

urlpatterns = patterns('rsvp.views',
  (r'list/$', 'rsvp_list'),
  (r'add/$', 'add_rsvp'),
  (r'update/$', 'update_rsvp'),
)
