from django.contrib import admin
from rsvp.models import RSVP

# Register your models here.


class RSVPAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'attend', 'email', 'guest_number', 'food_allergies', 'event', 'comment')
    #ordering = ('id',)
    search_fields = ('name', 'email')
    #list_filter = ()
    list_editable = ('attend', 'event')

admin.site.register(RSVP, RSVPAdmin)

