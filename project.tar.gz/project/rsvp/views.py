from django.shortcuts import render
from django.http import HttpResponse

from rsvp.models import RSVP

# Create your views here.

def hello_test(request):
    return HttpResponse('hello test from john')

def rsvp_list(request):
    rsvps = RSVP.objects.all().values()
    return HttpResponse(rsvps)

def add_rsvp(request):
    print request.REQUEST

    name = request.REQUEST.get('name', '')

    attend = request.REQUEST.get('attend', '')
    no_attend = request.REQUEST.get('no_attend', '')
    notsure_attend = request.REQUEST.get('notsure_attend', '')

    email = request.REQUEST.get('email', '')
    guest_number = request.REQUEST.get('guest_number', '')
    food_allergies = request.REQUEST.get('food_allergies', '')
    comment = request.REQUEST.get('comment', '')

    event_str = []
    for i in range(1, 6):
        key = 'event%s' % i
        e = request.REQUEST.get(key, '')
        if e:
            event_str.append(key)
    event_str = ', '.join(event_str)
    if attend == 'on':
        attend_enum = 1
    if no_attend == 'on':
        attend_enum = 2
    if notsure_attend == 'on':
        attend_enum = 3

    rsvp = RSVP()
    rsvp.name = name
    rsvp.attend = attend_enum
    rsvp.email = email
    rsvp.guest_number = guest_number
    rsvp.food_allergies = food_allergies
    rsvp.event = event_str
    rsvp.comment = comment

    rsvp.save()

    ret = str(request.REQUEST)
    ret = 'success, thanks'
    return HttpResponse(ret)

def update_rsvp(request):
    return HttpResponse('hello')
