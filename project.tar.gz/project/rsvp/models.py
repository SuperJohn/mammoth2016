from django.db import models

# Create your models here.

# {u'comment': u'ccc', u'dessert_food': u'Twix with ice cream on top', u'name': u'test1', u'notsure_attend': u'on', u'main_food': u'Wine Only', u'menu_notes': u'test mn', u'phone': u't3', u'guest_number': u'4', u'event4': u'on', u'email': u'tes2', u'event1': u'on'}


eventChoices = (
  (1, 'Welcome Party (location TBD)'),
  (2, 'Group Skiing / lunch at Mammoth Mountain'),
  (3, 'Rehearsal Dinner at Mammoth Brewing Co'),
  (4, 'Ceremony & Reception at Mammoth Mountain'),
  (5, "Good-bye Breakfast at the Sullivan's"),
)
attendChoices = (
  (0, 'unknown'),
  (1, 'yes'),
  (2, 'no'),
  (3, 'not sure'),
)


class RSVP(models.Model):
    name = models.CharField("name", max_length=80, default='')
    attend = models.IntegerField("attend", default=0, choices=attendChoices)
    email = models.CharField("email", max_length=80, default='')
    guest_number = models.CharField("guest number", max_length=100, default='')
    food_allergies = models.CharField("food allergies", max_length=200, default='')
    event = models.CharField("event", default='', max_length=100)
    comment = models.CharField("comment", max_length=500, default='')

    create_time = models.DateTimeField("create_time", auto_now_add=True)
    update_time = models.DateTimeField("update_time", auto_now=True)

    class Meta():
        db_table = 'rsvp'
        verbose_name = 'rsvp'
        verbose_name_plural = 'rsvps'

    def __str__(self):
        return '%s/%s' % (self.id, self.name)

